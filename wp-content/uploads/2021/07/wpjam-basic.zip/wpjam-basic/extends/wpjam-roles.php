<?php
/*
Plugin Name: 用户角色
Plugin URI: http://wpjam.net/item/wpjam-basic/
Description: 用户角色管理，以及用户额外权限设置。
Version: 1.0
*/