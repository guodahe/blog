<?php
do_action('wpjam_user_page_file');