<?php
/*
Plugin Name: 文章类型转换器
Plugin URI: http://blog.wpjam.com/project/wpjam-basic/
Description: 文章类型转换器，可以将文章在多种文章类型中进行转换。
Version: 1.0
*/