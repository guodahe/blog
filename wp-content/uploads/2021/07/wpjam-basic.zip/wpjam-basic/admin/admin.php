<?php
include WPJAM_BASIC_PLUGIN_DIR.'admin/core/core.php';
include WPJAM_BASIC_PLUGIN_DIR.'admin/core/hooks.php';
include WPJAM_BASIC_PLUGIN_DIR.'admin/core/functions.php';

include WPJAM_BASIC_PLUGIN_DIR.'admin/hooks/admin-menus.php';	// 后台菜单
include WPJAM_BASIC_PLUGIN_DIR.'admin/hooks/custom.php';		// 自定义后台
include WPJAM_BASIC_PLUGIN_DIR.'admin/hooks/stats.php';			// 后台统计基础函数
include WPJAM_BASIC_PLUGIN_DIR.'admin/hooks/verify.php';		// 验证
include WPJAM_BASIC_PLUGIN_DIR.'admin/hooks/topic.php';			// 讨论组